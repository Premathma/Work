package net.vehicle.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.vehicle.springboot.repository.AdminRepository;
import net.vehicle.springboot.users.Admin;




@RestController
@RequestMapping("api/")

public class AdminController {
	
	@Autowired
	private AdminRepository adminRepository;
	
	@GetMapping("Admin")
	public List<Admin> getAdmin(){
		return this.adminRepository.findAll();
	}

}
