package net.vehicle.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import net.vehicle.springboot.repository.AddBikeRepository;
import net.vehicle.springboot.repository.AddCarRepository;
import net.vehicle.springboot.repository.AdminRepository;
import net.vehicle.springboot.users.AddBike;
import net.vehicle.springboot.users.AddCar;
import net.vehicle.springboot.users.Admin;

@SpringBootApplication
public class ShowroomBackendApplication implements CommandLineRunner {

   

	public static void main(String[] args) {
		SpringApplication.run(ShowroomBackendApplication.class, args);
	}
	@Autowired
	private AdminRepository adminRepository;
	
	@Override
	public void run(String...args) throws Exception{
		this.adminRepository.save(new Admin("prem","poojary","prem@gmail.com","BSC CS"));
	}
	
	

}
