package net.vehicle.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.vehicle.springboot.users.Admin;

@Repository
public interface AdminRepository  extends JpaRepository<Admin, Long>{

}
