package net.vehicle.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.vehicle.springboot.repository.AddBikeRepository;
import net.vehicle.springboot.users.AddBike;

@RestController
@RequestMapping("api/")
public class AddBikeController {
	
	@Autowired
	private AddBikeRepository addBikeRepository;
	
	@GetMapping("AddCaR")
	public List<AddBike> getAddBike(){
		return this.addBikeRepository.findAll();
	}

}
