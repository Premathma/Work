package net.vehicle.springboot.users;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "Car")

public class AddCar {
	
	@Column(name = "Car_Brand")
	private String Cbrand;
	@Column(name = "Car_Model")
	private String CModel;
	@Column(name = "Car_Year")
	private int CYear;
	@Column(name = "Car_Price")
	private int CPrice;
	@Column(name = "Car_Color")
	private String CColor;
	
public AddCar() {
		
	}
	
	
	
	
	public AddCar(String cbrand, String cModel, int cYear, int cPrice, String cColor) {
		super();
		Cbrand = cbrand;
		CModel = cModel;
		CYear = cYear;
		CPrice = cPrice;
		CColor = cColor;
	}
	public String getCbrand() {
		return Cbrand;
	}
	public void setCbrand(String cbrand) {
		Cbrand = cbrand;
	}
	public String getCModel() {
		return CModel;
	}
	public void setCModel(String cModel) {
		CModel = cModel;
	}
	public int getCYear() {
		return CYear;
	}
	public void setCYear(int cYear) {
		CYear = cYear;
	}
	public int getCPrice() {
		return CPrice;
	}
	public void setCPrice(int cPrice) {
		CPrice = cPrice;
	}
	public String getCColor() {
		return CColor;
	}
	public void setCColor(String cColor) {
		CColor = cColor;
	}

}
