package net.vehicle.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.vehicle.springboot.users.AddBike;

public interface AddBikeRepository extends JpaRepository<AddBike, Long>{

}
