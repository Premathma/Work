package net.vehicle.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.vehicle.springboot.users.AddCar;


public interface AddCarRepository extends JpaRepository<AddCar, Long>{

}
