package net.vehicle.springboot.users;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "Bike")

public class AddBike {

	@Column(name = "Bike_Brand")
	private String bbrand;
	@Column(name = "Bike_Model")
	private String bModel;
	@Column(name = "Bike_Year")
	private int bYear;
	@Column(name = "Bike_Price")
	private int bPrice;
	@Column(name = "Bike_Color")
	private String bColor;
	
	
public AddBike() {
		
	}
	
	
	public AddBike(String bbrand, String bModel, int bYear, int bPrice, String bColor) {
		super();
		this.bbrand = bbrand;
		this.bModel = bModel;
		this.bYear = bYear;
		this.bPrice = bPrice;
		this.bColor = bColor;
	}
	public String getBbrand() {
		return bbrand;
	}
	public void setBbrand(String bbrand) {
		this.bbrand = bbrand;
	}
	public String getbModel() {
		return bModel;
	}
	public void setbModel(String bModel) {
		this.bModel = bModel;
	}
	public int getbYear() {
		return bYear;
	}
	public void setbYear(int bYear) {
		this.bYear = bYear;
	}
	public int getbPrice() {
		return bPrice;
	}
	public void setbPrice(int bPrice) {
		this.bPrice = bPrice;
	}
	public String getbColor() {
		return bColor;
	}
	public void setbColor(String bColor) {
		this.bColor = bColor;
	}
	
	
	
}

