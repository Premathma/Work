package net.vehicle.springboot.users;

public class Client {

}
