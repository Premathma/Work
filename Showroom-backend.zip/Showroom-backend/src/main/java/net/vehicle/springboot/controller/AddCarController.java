package net.vehicle.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.vehicle.springboot.repository.AddCarRepository;
import net.vehicle.springboot.users.AddCar;


@RestController
@RequestMapping("api/")
public class AddCarController {
	
	@Autowired
	private AddCarRepository addCarRepository;
	
	@GetMapping("AddCaR")
	public List<AddCar> getAddCar(){
		return this.addCarRepository.findAll();
	}

}
