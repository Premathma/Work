package net.vehicle.springboot.users;

import jakarta.persistence.*;

@Entity
@Table(name = "staff")

public class Admin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "Staff_first_name")
	private String stafffirstName;

	@Column(name = "Staff_last_name")
	private String stafflastName;
	
	@Column(name = "Staff_email_id")
	private String staffemailId;
	
	@Column(name = "Staff_education_id")
	private String staffeducation;
	
	
	public Admin() {
		
	}

	public Admin(String stafffirstName, String stafflastName, String staffemailId, String staffeducation) {
		super();
		this.stafffirstName = stafffirstName;
		this.stafflastName = stafflastName;
		this.staffemailId = staffemailId;
		this.staffeducation = staffeducation;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStafffirstName() {
		return stafffirstName;
	}

	public void setStafffirstName(String stafffirstName) {
		this.stafffirstName = stafffirstName;
	}

	public String getStafflastName() {
		return stafflastName;
	}

	public void setStafflastName(String stafflastName) {
		this.stafflastName = stafflastName;
	}

	public String getStaffemailId() {
		return staffemailId;
	}

	public void setStaffemailId(String staffemailId) {
		this.staffemailId = staffemailId;
	}

	public String getStaffeducation() {
		return staffeducation;
	}

	public void setStaffeducation(String staffeducation) {
		this.staffeducation = staffeducation;
	}
	

}
